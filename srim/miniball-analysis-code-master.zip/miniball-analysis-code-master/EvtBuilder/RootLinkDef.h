#ifdef __CINT__
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
//#pragma extra_include "/home/vbild/mbsio/BuiltEvent.hh"
//#pragma extra_include "/home/vbild/mbsio/Datas.hh"
//#pragma extra_include "/home/vbild/mbsio/EventBuilder.hh"
//#pragma extra_include "/home/vbild/mbsio/EventBuffer.hh"
//#pragma extra_include "/home/vbild/mbsio/GlobalSettings.hh"
//#pragma extra_include "/home/vbild/mbsio/Modules.hh"
//#pragma extra_include "/home/vbild/mbsio/SubEvents.hh"
//#pragma extra_include "/home/vbild/mbsio/UnpackedEvent.hh"
#pragma link C++ class BuiltEvent+;
#pragma link C++ class AdcData+;
#pragma link C++ class DgfData+;
#pragma link C++ class EventBuffer+;
#pragma link C++ class EventBuilder+;
#pragma link C++ class GlobalSettings+;
#pragma link C++ class DgfModule+;
#pragma link C++ class AdcModule+;
#pragma link C++ class PatternUnit+;
#pragma link C++ class SISScaler+;
#pragma link C++ class DgfScaler+;
#pragma link C++ class BraggChamber+;
#pragma link C++ class DgfSubEvent+;
#pragma link C++ class AdcSubEvent+;
#pragma link C++ class PatternUnitSubEvent+;
#pragma link C++ class ScalerSubEvent+;
#pragma link C++ class DgfScalerSubEvent+;
#pragma link C++ class BraggChamberSubEvent+;
#pragma link C++ class UnpackedEvent+;
#pragma link C++ class Calibration+;
#pragma link C++ class MBGeometry+;
#pragma link C++ class mbevts+;
#endif
