#include "typedefs.h"
/* Generated from EE$ROOT:[GOOFY.VME]SA$VESFB.VMETEMP;  */
/* Swapping enabled           */
  /*  ================= GSI VME Fastbus header ==================  */
  /*  Fastbus module header maps to IA$ves10_1[i]  */
typedef struct
{
CHARS h_lwords;   /*  Number of longwords following */
CHARS h_addr;   /*  Geo. Address */
INTS2 i_id;   /*  Fastbus module ID */
} s_vesfb;
  /* ------------------------------------------------------------- */
