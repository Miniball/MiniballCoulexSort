#ifdef __CINT__
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#pragma link C++ class MBGeometry+;
#pragma link C++ class SpedeGeometry+;
#pragma link C++ class hists+;
#pragma link C++ class doppler+;
#pragma link C++ class mbevts+;
#pragma link C++ class g_clx+;
#endif
